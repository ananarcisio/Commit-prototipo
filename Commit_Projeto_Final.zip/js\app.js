/**
 * COMMIT! — Sistema Web Educacional
 * Equipe: Grupo 3 - 2026.2
 * Tecnologias: HTML5, CSS3, Vanilla JavaScript, localStorage
 * Identidade Visual e Design Tokens conforme DESIGN.md e Relatório IHC v3.0
 * Paleta Oficial: Primary (#17324D), Secondary (#0D8FA8), Surface (#CAD7E4),
 *                 Background (#F8FAFC), Error (#A61B1B), Success (#1B5E20)
 */

// ==========================================================================
// 1. DADOS INICIAIS (CATÁLOGO DE DESAFIOS E CONQUISTAS)
// ==========================================================================

const INITIAL_CHALLENGES = [
  {
    id: "mercado",
    title: "Mercado",
    subtitle: "Implementação de sistema de caixa",
    level: "Iniciante",
    tags: ["Loop", "Vetor", "if/else", "Operadores"],
    quote: "O desafio propõe a criação de um sistema básico de leitura de código de produtos, cálculo do valor final da compra do cliente, e validação de erros nas leituras.",
    description: "Neste desafio prático, você construirá o núcleo lógico de um terminal de caixa de supermercado. O sistema deve ler códigos de barras simulados, identificar preços em uma tabela predefinida, aplicar regras de desconto para compras acima de R$ 100,00 e emitir o extrato final com cálculo do troco a ser devolvido.",
    requirements: [
      "Criar uma tabela/vetor de produtos com ao menos 5 itens (código, nome e preço unitário).",
      "Implementar um laço de repetição para ler produtos até a finalização da compra.",
      "Validar se o código informado existe; caso contrário, emitir mensagem amigável de erro.",
      "Calcular o total e aplicar 10% de desconto para compras acima de R$ 100,00.",
      "Calcular e exibir o troco a partir do valor pago pelo cliente."
    ],
    steps: [
      "Passo 1: Estruture a lista de produtos com códigos numéricos e seus respectivos preços.",
      "Passo 2: Crie a função de adição ao carrinho com verificação de código inválido.",
      "Passo 3: Aplique a condicional de desconto e a fórmula de troco.",
      "Passo 4: Organize o código em seu repositório GitHub e registre a entrega abaixo."
    ],
    isWeeklyPick: true
  },
  {
    id: "media-nota",
    title: "Média de nota",
    subtitle: "Cálculo dinâmico escolar",
    level: "Iniciante",
    tags: ["Operadores", "Loop", "if/else"],
    quote: "Consiste de fazer a média de uma quantidade não determinada de notas de um aluno",
    description: "Desenvolva um programa didático para professores calcularem a média de notas de seus estudantes. O sistema deve aceitar tantas notas quantas o usuário desejar inserir até que um valor especial de encerramento seja digitado. Ao final, classifica a situação acadêmica do aluno.",
    requirements: [
      "Aceitar entrada indeterminada de notas válidas (0 a 10) usando um sentinela de parada (ex: -1).",
      "Calcular a média aritmética simples com arredondamento em 2 casas decimais.",
      "Classificar o resultado: Média >= 7.0 (Aprovado), entre 5.0 e 6.9 (Recuperação), < 5.0 (Reprovado).",
      "Identificar e exibir a maior e a menor nota inseridas."
    ],
    steps: [
      "Passo 1: Crie o laço de repetição com acumulador de notas e contador de avaliações.",
      "Passo 2: Trate entradas inválidas (notas negativas fora do sentinela ou maiores que 10).",
      "Passo 3: Exiba o relatório com média e o status pedagógico final."
    ],
    isWeeklyPick: true
  },
  {
    id: "padaria",
    title: "Sistema Padaria",
    subtitle: "Gestão de estoque e vendas",
    level: "Intermediário",
    tags: ["Métodos", "Classes", "POO"],
    quote: "Crud de um sistema de cadastro de produtos de padaria.",
    description: "Aplique os pilares da Programação Orientada a Objetos para gerenciar o estoque de delícias de uma padaria (pães, bolos, salgados e cafés). Crie classes bem definidas com métodos para adicionar, consultar, atualizar quantidades e dar baixa após vendas.",
    requirements: [
      "Definir a classe 'Produto' com atributos: código, nome, categoria, preço e estoque.",
      "Criar métodos para listar produtos, atualizar preços e controlar níveis de estoque.",
      "Implementar alerta visual quando a quantidade em estoque for inferior a 5 unidades.",
      "Simular transações de venda com desconto automático para itens do dia anterior."
    ],
    steps: [
      "Passo 1: Modele as classes com métodos de encapsulamento.",
      "Passo 2: Implemente a estrutura CRUD (Criar, Ler, Atualizar, Deletar).",
      "Passo 3: Valide cenários de tentativa de venda sem estoque suficiente."
    ],
    isWeeklyPick: true
  },
  {
    id: "tarefas",
    title: "Checklist de tarefas diárias",
    subtitle: "Organização e produtividade pessoal",
    level: "Iniciante",
    tags: ["Vetor", "Métodos", "Strings"],
    quote: "O desafio propõe a criação de um sistema básico de checagem de tarefas do dia a dia do usuário",
    description: "Construa um gerenciador de tarefas diárias leve e interativo. O estudante poderá cadastrar atividades escolares e de estudo, marcá-las como concluídas com feedback visual e acompanhar um indicador de produtividade.",
    requirements: [
      "Armazenar tarefas em um vetor de objetos com id, título e indicador booleano de conclusão.",
      "Permitir alternar o estado de cada tarefa entre pendente e concluída.",
      "Calcular e exibir a porcentagem de tarefas já concluídas no dia.",
      "Impedir a inserção de tarefas vazias ou apenas com espaços em branco."
    ],
    steps: [
      "Passo 1: Crie o array de tarefas e a função de renderização.",
      "Passo 2: Implemente a alternância de estado (toggle) com clique.",
      "Passo 3: Adicione a contagem dinâmica de tarefas restantes."
    ],
    isWeeklyPick: false
  },
  {
    id: "clima",
    title: "Sistema de clima",
    subtitle: "Consumo de API meteorológica",
    level: "Avançado",
    tags: ["API", "Aplicação web", "Fetch"],
    quote: "O desafio propõe a criação de uma interface visual que consulta API's de clima em diversos locais no globo",
    description: "Conecte sua aplicação com o mundo real através de requisições assíncronas a uma API de previsão do tempo. O projeto exige tratamento de estados de carregamento (loading), exibição gráfica das condições e tratamento de exceções de conexão.",
    requirements: [
      "Utilizar a Fetch API com async/await para consultar previsões meteorológicas.",
      "Exibir temperatura atual, sensação térmica, umidade do ar e descrição do céu.",
      "Tratar erros de busca (cidade não encontrada) com mensagem amigável e ícone de alerta.",
      "Salvar as últimas 3 cidades pesquisadas para acesso rápido."
    ],
    steps: [
      "Passo 1: Configure a chamada assíncrona para o endpoint da API.",
      "Passo 2: Formate os dados JSON retornados e atualize os cartões da interface.",
      "Passo 3: Trate falhas de rede com caixas de alerta do Design System."
    ],
    isWeeklyPick: false
  },
  {
    id: "senhas",
    title: "Gerador de senhas seguras",
    subtitle: "Segurança e manipulação de strings",
    level: "Iniciante",
    tags: ["Operadores", "Strings", "Loop"],
    quote: "Crie um utilitário de geração de senhas criptograficamente fortes com opções de customização de caracteres.",
    description: "Desenvolva uma ferramenta didática para criar senhas fortes e aleatórias. O usuário escolhe o comprimento e quais conjuntos de caracteres incluir (maiúsculas, minúsculas, números e caracteres especiais).",
    requirements: [
      "Permitir ajustar o tamanho da senha entre 8 e 32 caracteres.",
      "Permitir ativar ou desativar opções de símbolos, números e letras maiúsculas.",
      "Calcular um medidor visual de força da senha gerada.",
      "Permitir copiar a senha para a área de transferência com um clique."
    ],
    steps: [
      "Passo 1: Crie os vetores de caracteres correspondentes a cada opção.",
      "Passo 2: Implemente o laço de seleção randômica balanceada.",
      "Passo 3: Adicione o feedback visual de cópia realizada."
    ],
    isWeeklyPick: false
  },
  {
    id: "banco",
    title: "Conta bancária digital",
    subtitle: "Transações e controle de saldo",
    level: "Intermediário",
    tags: ["POO", "Classes", "Métodos"],
    quote: "Simule operações financeiras de depósitos, saques com limite de cheque especial e extrato bancário.",
    description: "Modele a estrutura orientada a objetos de um banco digital moderno. Crie contas correntes e poupança com regras estritas de transação, registro cronológico de extrato e proteção contra saldo negativo além do limite acordado.",
    requirements: [
      "Criar a classe ContaBancaria com atributos privados de saldo, titular e número da conta.",
      "Implementar métodos sacar(), depositar() e transferir() com validações numéricas.",
      "Armazenar um vetor de movimentações com data, tipo da operação e valor.",
      "Impedir saques superiores ao saldo disponível somado ao cheque especial."
    ],
    steps: [
      "Passo 1: Estruture a classe com métodos de validação de saldo.",
      "Passo 2: Crie a rotina de extrato formatado.",
      "Passo 3: Teste transferências entre duas instâncias de contas distintas."
    ],
    isWeeklyPick: false
  },
  {
    id: "ecommerce",
    title: "Mini E-Commerce",
    subtitle: "Catálogo e carrinho de compras",
    level: "Avançado",
    tags: ["POO", "Aplicação web", "Vetor", "Classes"],
    quote: "Construção de uma experiência completa de catálogo com filtros de produtos e carrinho interativo.",
    description: "Construa a lógica e a interface de uma loja online com produtos em destaque, cálculo automático de frete simulado por região, aplicação de cupons promocionais e resumo final do pedido.",
    requirements: [
      "Gerenciar um estado dinâmico do carrinho (adicionar item, mudar quantidade, excluir).",
      "Calcular subtotal, desconto de cupom promocional e taxa de frete.",
      "Persistir o carrinho para manter os produtos mesmo se o usuário recarregar a página.",
      "Validar estoque máximo disponível por produto."
    ],
    steps: [
      "Passo 1: Desenvolva a visualização dos produtos disponíveis.",
      "Passo 2: Crie as funções de manipulação do carrinho de compras.",
      "Passo 3: Implemente as regras de cálculo e validação de cupons."
    ],
    isWeeklyPick: false
  },
  {
    id: "chat",
    title: "Chat em tempo real",
    subtitle: "Mensageria e eventos de interface",
    level: "Avançado",
    tags: ["API", "Aplicação web", "Métodos"],
    quote: "Interface interativa simulando mensageria com histórico de conversas e alternância de participantes.",
    description: "Crie uma aplicação simulando troca de mensagens instantâneas entre usuários em um canal de estudos. Implemente rolagem automática de conversas, carimbo de data/hora e respostas automatizadas com atraso simulado.",
    requirements: [
      "Permitir envio e visualização de mensagens com identificação do remetente e horário.",
      "Alternar rapidamente entre o perfil do usuário e um bot de mentoria escolar.",
      "Simular respostas automáticas do tutor após 1,5 segundo de envio da dúvida.",
      "Manter a rolagem automática sempre ancorada na mensagem mais recente."
    ],
    steps: [
      "Passo 1: Estruture o layout de mensagens com caixas de diálogo.",
      "Passo 2: Implemente o evento de envio por clique e pela tecla Enter.",
      "Passo 3: Crie a simulação de resposta do assistente de estudos."
    ],
    isWeeklyPick: false
  }
];

const ACHIEVEMENTS_DEFINITIONS = [
  {
    id: "welcome",
    title: "Bem-vindo ao Commit!",
    description: "Criou sua conta na plataforma e deu o pontapé inicial na sua jornada dev."
  },
  {
    id: "first_step",
    title: "Primeiro Passo",
    description: "Iniciou seu primeiro desafio no catálogo de projetos."
  },
  {
    id: "in_progress_50",
    title: "Mão na Massa",
    description: "Atingiu 50% de progresso prático em um dos desafios."
  },
  {
    id: "first_commit",
    title: "Primeiro Commit!",
    description: "Enviou seu primeiro repositório do GitHub registrado na plataforma."
  },
  {
    id: "first_completion",
    title: "Missão Cumprida",
    description: "Concluiu seu primeiro desafio com 100% dos requisitos finalizados!"
  },
  {
    id: "profile_custom",
    title: "Identidade Dev",
    description: "Personalizou seu perfil, bio e sua tag individual de programador."
  },
  {
    id: "explorer",
    title: "Explorador Curioso",
    description: "Utilizou a busca e os filtros avançados no catálogo de desafios."
  },
  {
    id: "bookmarker",
    title: "Colecionador",
    description: "Salvou 3 ou mais desafios na sua lista de favoritos para estudar depois."
  },
  {
    id: "three_completed",
    title: "Programador Consistente",
    description: "Concluiu com sucesso 3 ou mais projetos na plataforma."
  },
  {
    id: "advanced_master",
    title: "Mestre dos Algoritmos",
    description: "Concluiu um projeto de nível Avançado com repositório entregue!"
  }
];

// ==========================================================================
// 2. HELPER DE ÍCONES SVG (Tabler Icons Inline)
// ==========================================================================

const Icons = {
  home: (cls = "") => `<svg class="${cls}" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12l-2 0l9 -9l9 9l-2 0"></path><path d="M5 12v7a2 2 0 0 0 2 2h10a2 2 0 0 0 2 -2v-7"></path><path d="M9 21v-6a2 2 0 0 1 2 -2h2a2 2 0 0 1 2 2v6"></path></svg>`,
  target: (cls = "") => `<svg class="${cls}" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"></circle><circle cx="12" cy="12" r="5"></circle><circle cx="12" cy="12" r="1"></circle></svg>`,
  user: (cls = "") => `<svg class="${cls}" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 7a4 4 0 1 0 8 0a4 4 0 0 0 -8 0"></path><path d="M6 21v-2a4 4 0 0 1 4 -4h4a4 4 0 0 1 4 4v2"></path></svg>`,
  trophy: (cls = "") => `<svg class="${cls}" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 21l8 0"></path><path d="M12 17l0 4"></path><path d="M7 4l10 0"></path><path d="M17 4v8a5 5 0 0 1 -10 0v-8"></path><path d="M5 9m-2 0a2 2 0 1 0 4 0a2 2 0 1 0 -4 0"></path><path d="M19 9m-2 0a2 2 0 1 0 4 0a2 2 0 1 0 -4 0"></path></svg>`,
  lock: (cls = "") => `<svg class="${cls}" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 11m0 2a2 2 0 0 1 2 -2h10a2 2 0 0 1 2 2v6a2 2 0 0 1 -2 2h-10a2 2 0 0 1 -2 -2z"></path><path d="M8 11v-4a4 4 0 0 1 8 0v4"></path></svg>`,
  bookmark: (cls = "", filled = false) => `<svg class="${cls}" width="20" height="20" viewBox="0 0 24 24" fill="${filled ? 'currentColor' : 'none'}" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 7v14l-6 -4l-6 4v-14a4 4 0 0 1 4 -4h4a4 4 0 0 1 4 4z"></path></svg>`,
  search: (cls = "") => `<svg class="${cls}" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 10m-7 0a7 7 0 1 0 14 0a7 7 0 1 0 -14 0"></path><path d="M21 21l-6 -6"></path></svg>`,
  pencil: (cls = "") => `<svg class="${cls}" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 20h4l10.5 -10.5a2.828 2.828 0 1 0 -4 -4l-10.5 10.5v4"></path><path d="M13.5 6.5l4 4"></path></svg>`,
  arrowRight: (cls = "") => `<svg class="${cls}" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12l14 0"></path><path d="M13 18l6 -6"></path><path d="M13 6l6 6"></path></svg>`,
  check: (cls = "") => `<svg class="${cls}" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12l5 5l10 -10"></path></svg>`,
  x: (cls = "") => `<svg class="${cls}" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6l-12 12"></path><path d="M6 6l12 12"></path></svg>`,
  alert: (cls = "") => `<svg class="${cls}" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 9v4"></path><path d="M12 16v.01"></path><path d="M5 19h14a2 2 0 0 0 1.84 -2.75l-7.1 -12.25a2 2 0 0 0 -3.5 0l-7.1 12.25a2 2 0 0 0 1.75 2.75"></path></svg>`,
  info: (cls = "") => `<svg class="${cls}" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 18 0a9 9 0 0 0 -18 0"></path><path d="M12 9h.01"></path><path d="M11 12h1v4h1"></path></svg>`,
  github: (cls = "") => `<svg class="${cls}" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 19c-4.3 1.4 -4.3 -2.5 -6 -3m12 5v-3.5c0 -1 .1 -1.4 -.5 -2c2.8 -.3 5.5 -1.4 5.5 -6a4.6 4.6 0 0 0 -1.3 -3.2a4.2 4.2 0 0 0 -.1 -3.2s-1.1 -.3 -3.5 1.3a12.3 12.3 0 0 0 -6.2 0c-2.4 -1.6 -3.5 -1.3 -3.5 -1.3a4.2 4.2 0 0 0 -.1 3.2a4.6 4.6 0 0 0 -1.3 3.2c0 4.6 2.7 5.7 5.5 6c-.6 .6 -.6 1.2 -.5 2v3.5"></path></svg>`,
  externalLink: (cls = "") => `<svg class="${cls}" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 6h-6a2 2 0 0 0 -2 2v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2 -2v-6"></path><path d="M11 13l9 -9"></path><path d="M15 4h5v5"></path></svg>`,
  sun: (cls = "") => `<svg class="${cls}" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="4"></circle><path d="M3 12h1m8 -9v1m8 8h1m-9 8v1m-6.4 -15.4l.7 .7m12.1 -.7l-.7 .7m0 11.4l.7 .7m-12.1 -.7l-.7 .7"></path></svg>`,
  moon: (cls = "") => `<svg class="${cls}" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3c.132 0 .263 0 .393 0a7.5 7.5 0 0 0 7.92 12.446a9 9 0 1 1 -8.313 -12.454z"></path></svg>`
};

// ==========================================================================
// 2.1. GERENCIADOR DE TEMA (MODO CLARO E MODO ESCURO — PDF IHC v3.0 Pág. 4)
// ==========================================================================

const THEME_STORAGE_KEY = "commit_theme";

function getCurrentTheme() {
  const saved = localStorage.getItem(THEME_STORAGE_KEY);
  if (saved === "dark" || saved === "light") return saved;
  if (window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches) {
    return "dark";
  }
  return "light";
}

function applyTheme(theme, notify = false) {
  document.documentElement.setAttribute("data-theme", theme);
  localStorage.setItem(THEME_STORAGE_KEY, theme);

  const iconEl = document.getElementById("theme-toggle-icon");
  const textEl = document.getElementById("theme-toggle-text");
  const btn = document.getElementById("btn-theme-toggle");

  if (iconEl && textEl) {
    if (theme === "dark") {
      iconEl.innerHTML = Icons.sun();
      textEl.textContent = "Modo Claro";
      if (btn) btn.title = "Alternar para Modo Claro";
    } else {
      iconEl.innerHTML = Icons.moon();
      textEl.textContent = "Modo Escuro";
      if (btn) btn.title = "Alternar para Modo Escuro";
    }
  }

  if (notify) {
    showToast(
      "Tema Atualizado",
      theme === "dark" ? "Modo escuro ativado com sucesso!" : "Modo claro ativado com sucesso!",
      "info"
    );
  }
}

function toggleTheme() {
  const current = getCurrentTheme();
  const next = current === "dark" ? "light" : "dark";
  applyTheme(next, true);
}

// Aplicação imediata para evitar flashes de tema ao carregar
applyTheme(getCurrentTheme(), false);

// ==========================================================================
// 3. GERENCIADOR DE ESTADO E LOCALSTORAGE
// ==========================================================================

const STORAGE_KEYS = {
  USERS: "commit_users",
  CURRENT_USER_ID: "commit_current_user_id",
  USER_DATA_PREFIX: "commit_user_data_"
};

class StateManager {
  constructor() {
    this.initDefaultUsers();
  }

  initDefaultUsers() {
    let users = this.getUsers();
    if (!users || users.length === 0) {
      const defaultUser = {
        id: "user_pedro",
        name: "Pedro Silva",
        username: "pedro.dev",
        email: "pedro@commit.edu",
        password: "123",
        tag: "Iniciante",
        bio: "Estudante apaixonado por lógica de programação e desenvolvimento de software."
      };

      const secondUser = {
        id: "user_ana",
        name: "Ana Clara",
        username: "ana.dev",
        email: "ana@commit.edu",
        password: "123",
        tag: "Frontend",
        bio: "Explorando a construção de interfaces web acessíveis e dinâmicas."
      };

      users = [defaultUser, secondUser];
      localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));

      // Dados pré-carregados para o usuário Pedro
      const pedroData = {
        challenges: {
          "mercado": {
            status: "in_progress",
            progress: 50,
            bookmarked: true,
            githubUrl: "https://github.com/pedro/desafio-mercado",
            githubDeliveredAt: "2026-11-05T14:30:00.000Z",
            checkedSteps: [0, 1]
          },
          "media-nota": {
            status: "completed",
            progress: 100,
            bookmarked: false,
            githubUrl: "https://github.com/pedro/media-de-notas",
            githubDeliveredAt: "2026-11-04T10:15:00.000Z",
            checkedSteps: [0, 1, 2, 3]
          },
          "padaria": {
            status: "in_progress",
            progress: 25,
            bookmarked: true,
            githubUrl: "",
            githubDeliveredAt: null,
            checkedSteps: [0]
          }
        },
        achievements: ["welcome", "first_step", "in_progress_50", "first_commit", "first_completion"]
      };

      const anaData = {
        challenges: {
          "clima": {
            status: "in_progress",
            progress: 75,
            bookmarked: true,
            githubUrl: "https://github.com/ana/clima-api",
            githubDeliveredAt: "2026-11-06T09:00:00.000Z",
            checkedSteps: [0, 1, 2]
          }
        },
        achievements: ["welcome", "first_step", "first_commit"]
      };

      localStorage.setItem(STORAGE_KEYS.USER_DATA_PREFIX + "user_pedro", JSON.stringify(pedroData));
      localStorage.setItem(STORAGE_KEYS.USER_DATA_PREFIX + "user_ana", JSON.stringify(anaData));
      
      localStorage.setItem(STORAGE_KEYS.CURRENT_USER_ID, "user_pedro");
    }
  }

  getUsers() {
    try {
      return JSON.parse(localStorage.getItem(STORAGE_KEYS.USERS)) || [];
    } catch (e) {
      return [];
    }
  }

  getCurrentUser() {
    const currentId = localStorage.getItem(STORAGE_KEYS.CURRENT_USER_ID);
    if (!currentId) return null;
    const users = this.getUsers();
    return users.find(u => u.id === currentId) || null;
  }

  setCurrentUser(userId) {
    if (userId) {
      localStorage.setItem(STORAGE_KEYS.CURRENT_USER_ID, userId);
    } else {
      localStorage.removeItem(STORAGE_KEYS.CURRENT_USER_ID);
    }
  }

  getUserData(userId) {
    if (!userId) return { challenges: {}, achievements: [] };
    const raw = localStorage.getItem(STORAGE_KEYS.USER_DATA_PREFIX + userId);
    if (raw) {
      try {
        return JSON.parse(raw);
      } catch (e) {
        return { challenges: {}, achievements: [] };
      }
    }
    const emptyData = { challenges: {}, achievements: [] };
    this.saveUserData(userId, emptyData);
    return emptyData;
  }

  saveUserData(userId, data) {
    if (!userId) return;
    localStorage.setItem(STORAGE_KEYS.USER_DATA_PREFIX + userId, JSON.stringify(data));
  }

  updateChallengeData(challengeId, updates) {
    const user = this.getCurrentUser();
    if (!user) return null;

    const data = this.getUserData(user.id);
    const existing = data.challenges[challengeId] || {
      status: "not_started",
      progress: 0,
      bookmarked: false,
      githubUrl: "",
      githubDeliveredAt: null,
      checkedSteps: []
    };

    data.challenges[challengeId] = { ...existing, ...updates };
    this.saveUserData(user.id, data);
    return data.challenges[challengeId];
  }

  toggleBookmark(challengeId) {
    const user = this.getCurrentUser();
    if (!user) return false;

    const data = this.getUserData(user.id);
    const existing = data.challenges[challengeId] || {
      status: "not_started",
      progress: 0,
      bookmarked: false,
      githubUrl: "",
      githubDeliveredAt: null,
      checkedSteps: []
    };

    existing.bookmarked = !existing.bookmarked;
    data.challenges[challengeId] = existing;
    this.saveUserData(user.id, data);

    const bookmarkedCount = Object.values(data.challenges).filter(c => c.bookmarked).length;
    if (bookmarkedCount >= 3) {
      this.unlockAchievement("bookmarker");
    }

    return existing.bookmarked;
  }

  unlockAchievement(achievementId) {
    const user = this.getCurrentUser();
    if (!user) return false;

    const data = this.getUserData(user.id);
    if (!data.achievements) data.achievements = [];

    if (!data.achievements.includes(achievementId)) {
      data.achievements.push(achievementId);
      this.saveUserData(user.id, data);

      const achDef = ACHIEVEMENTS_DEFINITIONS.find(a => a.id === achievementId);
      if (achDef) {
        showToast("Conquista Desbloqueada!", achDef.title, "achievement");
      }
      return true;
    }
    return false;
  }

  login(identifier, password) {
    const users = this.getUsers();
    const cleanId = identifier.trim().toLowerCase();
    const user = users.find(u => 
      (u.username.toLowerCase() === cleanId || u.email.toLowerCase() === cleanId) &&
      u.password === password
    );

    if (user) {
      this.setCurrentUser(user.id);
      this.unlockAchievement("welcome");
      return { success: true, user };
    }
    return { success: false, message: "Verifique os dados e tente novamente. Podemos ajudar?" };
  }

  register(name, username, email, password, tag, bio) {
    const users = this.getUsers();
    const cleanUsername = username.trim().toLowerCase().replace(/^@/, "");
    const cleanEmail = email.trim().toLowerCase();

    if (!name.trim()) return { success: false, message: "Opa! Informe seu nome completo." };
    if (!cleanUsername) return { success: false, message: "Opa! Informe um nome de usuário." };
    if (users.some(u => u.username.toLowerCase() === cleanUsername)) {
      return { success: false, message: "Este nome de usuário já está em uso. Tente outro!" };
    }
    if (users.some(u => u.email.toLowerCase() === cleanEmail)) {
      return { success: false, message: "Este e-mail já foi cadastrado." };
    }
    if (!password || password.length < 3) {
      return { success: false, message: "A senha deve ter pelo menos 3 caracteres." };
    }

    const newUser = {
      id: "user_" + Date.now(),
      name: name.trim(),
      username: cleanUsername,
      email: cleanEmail,
      password: password,
      tag: tag.trim() || "Iniciante",
      bio: bio.trim() || "Estudante de programação explorando o Commit!."
    };

    users.push(newUser);
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
    this.setCurrentUser(newUser.id);

    this.saveUserData(newUser.id, {
      challenges: {},
      achievements: ["welcome"]
    });

    showToast("Operação concluída.", `Bem-vindo ao Commit!, ${newUser.name}!`, "success");
    return { success: true, user: newUser };
  }

  updateProfile(name, username, tag, email, bio) {
    const user = this.getCurrentUser();
    if (!user) return { success: false, message: "Nenhum usuário logado." };

    const cleanName = name.trim();
    const cleanUsername = username.trim().toLowerCase().replace(/^@/, "");

    if (!cleanName) return { success: false, message: "O campo Nome não pode ficar vazio." };
    if (!cleanUsername) return { success: false, message: "O campo Nome de Usuário não pode ficar vazio." };

    const users = this.getUsers();
    if (users.some(u => u.id !== user.id && u.username.toLowerCase() === cleanUsername)) {
      return { success: false, message: "Este nome de usuário já pertence a outra conta." };
    }

    user.name = cleanName;
    user.username = cleanUsername;
    user.tag = tag.trim() || "Iniciante";
    user.email = email.trim() || user.email;
    user.bio = bio.trim() || user.bio;

    const userIndex = users.findIndex(u => u.id === user.id);
    if (userIndex !== -1) {
      users[userIndex] = user;
      localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
    }

    this.unlockAchievement("profile_custom");
    showToast("Operação concluída.", "Seu perfil foi atualizado com sucesso!", "success");
    return { success: true, user };
  }

  logout() {
    this.setCurrentUser(null);
    showToast("Sessão encerrada.", "Você saiu da sua conta.", "info");
  }
}

const state = new StateManager();

// ==========================================================================
// 4. SISTEMA DE TOAST E NOTIFICAÇÕES VISUAIS
// ==========================================================================

function showToast(title, message, type = "info") {
  const container = document.getElementById("toast-container");
  if (!container) return;

  const toast = document.createElement("div");
  toast.className = `toast-message ${type}`;

  let iconSvg = Icons.info();
  if (type === "achievement") iconSvg = Icons.trophy();
  if (type === "success") iconSvg = Icons.check();
  if (type === "error") iconSvg = Icons.alert();

  toast.innerHTML = `
    <div class="toast-icon">${iconSvg}</div>
    <div class="toast-text">
      <strong>${title}</strong>
      <p>${message}</p>
    </div>
  `;

  toast.addEventListener("click", () => toast.remove());
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.transition = "opacity 0.3s ease, transform 0.3s ease";
    toast.style.opacity = "0";
    toast.style.transform = "translateX(50px)";
    setTimeout(() => toast.remove(), 300);
  }, 4500);
}

// ==========================================================================
// 5. RENDERIZAÇÃO DAS TELAS E COMPONENTES
// ==========================================================================

function renderTopUserBar() {
  const user = state.getCurrentUser();
  const userStatusWrap = document.getElementById("top-user-info");
  if (!userStatusWrap) return;

  if (user) {
    userStatusWrap.innerHTML = `
      <div class="user-status-pill">
        <span class="status-dot"></span>
        <span>Conectado como <strong>${escapeHtml(user.username)}</strong></span>
      </div>
      <button class="btn-header-action" id="btn-logout" title="Encerrar sessão">
        ${Icons.user()} Sair
      </button>
    `;
    const btnLogout = document.getElementById("btn-logout");
    if (btnLogout) {
      btnLogout.addEventListener("click", () => {
        state.logout();
        renderAllViews();
      });
    }
  } else {
    userStatusWrap.innerHTML = `
      <div class="user-status-pill guest">
        <span class="status-dot"></span>
        <span>Modo Visitante</span>
      </div>
      <button class="btn-header-action primary-cta" id="btn-open-auth">
        ${Icons.user()} Entrar / Cadastrar
      </button>
    `;
    const btnAuth = document.getElementById("btn-open-auth");
    if (btnAuth) {
      btnAuth.addEventListener("click", () => openAuthModal("login"));
    }
  }
}

function escapeHtml(str) {
  if (!str) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function createChallengeCardHtml(challenge, userChallengeData = null, showProgress = false) {
  const isBookmarked = userChallengeData?.bookmarked || false;
  const progress = userChallengeData?.progress || 0;
  const levelClass = challenge.level.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");

  const tagsHtml = challenge.tags.map(tag => 
    `<span class="tag-badge tech">${escapeHtml(tag)}</span>`
  ).join("");

  let progressHtml = "";
  if (showProgress) {
    progressHtml = `
      <div class="card-progress-wrap">
        <div class="progress-bar-outer" role="progressbar" aria-valuenow="${progress}" aria-valuemin="0" aria-valuemax="100">
          <div class="progress-bar-inner" style="width: ${progress}%"></div>
        </div>
        <span class="progress-label">${progress}%</span>
      </div>
    `;
  }

  return `
    <article class="challenge-card level-card-${levelClass}" data-id="${challenge.id}">
      <div>
        <div class="card-top-row">
          <div class="card-title-group">
            <h3 class="card-title">${escapeHtml(challenge.title)}</h3>
            <p class="card-subtitle">${escapeHtml(challenge.subtitle)}</p>
          </div>
          <button class="btn-bookmark ${isBookmarked ? 'bookmarked' : ''}" data-action="bookmark" data-id="${challenge.id}" title="${isBookmarked ? 'Remover dos favoritos' : 'Salvar nos favoritos'}" aria-label="Favoritar desafio">
            ${Icons.bookmark("", isBookmarked)}
          </button>
        </div>

        <div class="card-tags">
          <span class="tag-badge level-${levelClass}">Nível: ${escapeHtml(challenge.level)}</span>
          ${tagsHtml}
        </div>

        <p class="card-description">"${escapeHtml(challenge.quote)}"</p>
      </div>

      <div class="card-footer">
        ${progressHtml}
        <button class="btn-open-challenge" data-action="open-modal" data-id="${challenge.id}">
          Abrir desafio <span>&rarr;</span>
        </button>
      </div>
    </article>
  `;
}

// RENDERIZAÇÃO DA TELA HOME
function renderHomeView() {
  const user = state.getCurrentUser();
  const userData = state.getUserData(user?.id);

  const greetingEl = document.getElementById("home-greeting");
  if (greetingEl) {
    const displayName = user ? user.name.split(" ")[0] : "Usuário";
    greetingEl.innerHTML = `Olá, <span class="greeting-accent">${escapeHtml(displayName)}!</span>`;
  }

  const homeGrid = document.getElementById("home-cards-grid");
  if (homeGrid) {
    const featured = INITIAL_CHALLENGES.slice(0, 5);
    let html = "";

    featured.forEach((ch, idx) => {
      const uData = userData.challenges[ch.id];
      
      if (idx === 1) {
        html += `
          <div class="achievement-bubble">
            <span class="trophy-icon">${Icons.trophy()}</span>
            <span><strong>Ana</strong> desbloqueou uma conquista! Conclua 10 projetos de nível intermediário.</span>
          </div>
        `;
      } else if (idx === 3) {
        html += `
          <div class="achievement-bubble">
            <span class="trophy-icon">${Icons.trophy()}</span>
            <span><strong>Luiz</strong> desbloqueou uma conquista! Meu primeiro projeto difícil!</span>
          </div>
        `;
      }

      html += createChallengeCardHtml(ch, uData, false);
    });

    homeGrid.innerHTML = html;
  }

  const weeklyGrid = document.getElementById("weekly-picks-grid");
  if (weeklyGrid) {
    const weekly = INITIAL_CHALLENGES.filter(c => c.isWeeklyPick).slice(0, 3);
    weeklyGrid.innerHTML = weekly.map(ch => 
      createChallengeCardHtml(ch, userData.challenges[ch.id], false)
    ).join("");
  }

  const btnExploreAction = document.getElementById("btn-explore-action");
  if (btnExploreAction) {
    if (user) {
      btnExploreAction.textContent = "Ver meu progresso →";
      btnExploreAction.onclick = () => switchView("profile");
    } else {
      btnExploreAction.textContent = "Criar conta →";
      btnExploreAction.onclick = () => openAuthModal("register");
    }
  }

  const btnCtaAction = document.getElementById("btn-home-cta-action");
  if (btnCtaAction) {
    if (user) {
      btnCtaAction.textContent = "Explorar catálogo →";
      btnCtaAction.onclick = () => switchView("catalog");
    } else {
      btnCtaAction.textContent = "Começar agora →";
      btnCtaAction.onclick = () => openAuthModal("register");
    }
  }
}

// RENDERIZAÇÃO DA TELA DE CATÁLOGO
let catalogFilter = {
  search: "",
  level: "Todos",
  tag: "Todos",
  status: "Todos"
};

function renderCatalogView() {
  const user = state.getCurrentUser();
  const userData = state.getUserData(user?.id);
  const catalogGrid = document.getElementById("catalog-cards-grid");
  if (!catalogGrid) return;

  const term = catalogFilter.search.trim().toLowerCase();

  const filtered = INITIAL_CHALLENGES.filter(ch => {
    if (term) {
      const matchTitle = ch.title.toLowerCase().includes(term);
      const matchSub = ch.subtitle.toLowerCase().includes(term);
      const matchQuote = ch.quote.toLowerCase().includes(term);
      const matchTags = ch.tags.some(t => t.toLowerCase().includes(term));
      const matchLevel = ch.level.toLowerCase().includes(term);
      if (!matchTitle && !matchSub && !matchQuote && !matchTags && !matchLevel) {
        return false;
      }
    }

    if (catalogFilter.level !== "Todos" && ch.level !== catalogFilter.level) {
      return false;
    }

    if (catalogFilter.tag !== "Todos" && !ch.tags.includes(catalogFilter.tag)) {
      return false;
    }

    if (catalogFilter.status !== "Todos") {
      const chData = userData.challenges[ch.id];
      if (catalogFilter.status === "Em andamento" && chData?.status !== "in_progress") return false;
      if (catalogFilter.status === "Concluídos" && chData?.status !== "completed") return false;
      if (catalogFilter.status === "Favoritos" && !chData?.bookmarked) return false;
    }

    return true;
  });

  if (filtered.length === 0) {
    catalogGrid.innerHTML = `
      <div class="empty-state-box" style="grid-column: 1 / -1;">
        <h3>Nenhum desafio encontrado</h3>
        <p>Não encontramos nenhum projeto correspondente aos filtros ou termos pesquisados.</p>
        <button class="btn-primary" id="btn-reset-catalog-filter">Limpar filtros de busca</button>
      </div>
    `;
    const btnReset = document.getElementById("btn-reset-catalog-filter");
    if (btnReset) {
      btnReset.onclick = () => {
        catalogFilter = { search: "", level: "Todos", tag: "Todos", status: "Todos" };
        const searchInput = document.getElementById("catalog-search-input");
        if (searchInput) searchInput.value = "";
        updateFilterPillsUi();
        renderCatalogView();
      };
    }
  } else {
    catalogGrid.innerHTML = filtered.map(ch => 
      createChallengeCardHtml(ch, userData.challenges[ch.id], false)
    ).join("");
  }

  if (term || catalogFilter.level !== "Todos" || catalogFilter.tag !== "Todos") {
    state.unlockAchievement("explorer");
  }
}

function updateFilterPillsUi() {
  document.querySelectorAll(".filter-pill[data-filter-group='level']").forEach(pill => {
    pill.classList.toggle("active", pill.dataset.value === catalogFilter.level);
  });
  document.querySelectorAll(".filter-pill[data-filter-group='status']").forEach(pill => {
    pill.classList.toggle("active", pill.dataset.value === catalogFilter.status);
  });
}

// RENDERIZAÇÃO DA TELA DE PERFIL
let currentProfileTab = "progress";

function renderProfileView() {
  const user = state.getCurrentUser();
  const profileHero = document.getElementById("profile-hero-content");
  const tabProgress = document.getElementById("profile-tab-progress-content");
  const tabAchievements = document.getElementById("profile-tab-achievements-content");

  if (!user) {
    if (profileHero) {
      profileHero.innerHTML = `
        <div class="profile-info-left">
          <div class="profile-name-row">
            <h1 class="profile-user-name">Modo Visitante</h1>
          </div>
          <p class="profile-handle">visitante.dev</p>
          <p style="margin-top: 12px; max-width: 500px;">Você está navegando sem login. Entre ou crie sua conta para registrar seu progresso, salvar favoritos e entregar repositórios no GitHub!</p>
          <div style="display: flex; gap: 12px; margin-top: 18px;">
            <button class="btn-secondary" onclick="openAuthModal('register')">Criar minha conta</button>
            <button class="btn-primary" onclick="openAuthModal('login')">Fazer login</button>
          </div>
        </div>
      `;
    }
    if (tabProgress) tabProgress.innerHTML = `<div class="empty-state-box"><p>Faça login para acompanhar seus desafios em andamento.</p></div>`;
    if (tabAchievements) tabAchievements.innerHTML = `<div class="empty-state-box"><p>Faça login para visualizar e desbloquear conquistas.</p></div>`;
    return;
  }

  const userData = state.getUserData(user.id);
  const userChallenges = Object.entries(userData.challenges || {});
  const completedCount = userChallenges.filter(([_, c]) => c.status === "completed").length;
  const inProgressList = userChallenges.filter(([_, c]) => c.status === "in_progress" || c.status === "completed");
  const achievementsCount = (userData.achievements || []).length;

  if (profileHero) {
    profileHero.innerHTML = `
      <div class="profile-decorative-ticks">
        <div class="profile-tick"></div>
        <div class="profile-tick"></div>
        <div class="profile-tick"></div>
      </div>

      <div class="profile-info-left">
        <div class="profile-name-row">
          <h1 class="profile-user-name">${escapeHtml(user.name)}</h1>
          <button class="btn-edit-profile" id="btn-trigger-edit-profile" title="Editar informações do perfil" aria-label="Editar perfil">
            ${Icons.pencil()}
          </button>
        </div>
        <p class="profile-handle">${escapeHtml(user.username.startsWith('@') ? user.username : '@' + user.username)}</p>

        <div class="profile-badges-row">
          <span class="profile-stat-badge accent-secondary"><strong>${achievementsCount}</strong> Conquistas</span>
          <span class="profile-stat-badge"><strong>${completedCount}</strong> Desafios feitos</span>
          <span class="profile-stat-badge">Tag: <strong>${escapeHtml(user.tag || "Iniciante")}</strong></span>
        </div>
      </div>

      <div class="profile-art-right">
        <!-- Estrela Sparkle com cores oficiais do Commit! -->
        <svg class="profile-star-sparkle" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M24 0L27.5 16.5L44 20L27.5 23.5L24 40L20.5 23.5L4 20L20.5 16.5L24 0Z" fill="#0D8FA8" stroke="#17324D" stroke-width="2.5" stroke-linejoin="round"/>
        </svg>

        <!-- Ondas topográficas vetoriais com a paleta oficial -->
        <svg class="profile-wave-lines" viewBox="0 0 200 120" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M10 90C40 70 80 110 130 60C160 30 180 40 200 50" stroke="#0D8FA8" stroke-width="2.2" fill="none"/>
          <path d="M10 80C45 60 85 100 135 50C165 20 185 30 200 40" stroke="#17324D" stroke-width="2.2" fill="none"/>
          <path d="M10 70C50 50 90 90 140 40C170 10 190 20 200 30" stroke="#0D8FA8" stroke-width="2.2" fill="none"/>
          <path d="M10 60C55 40 95 80 145 30C175 0 195 10 200 20" stroke="#17324D" stroke-width="2.2" fill="none"/>
        </svg>
      </div>
    `;

    const btnEdit = document.getElementById("btn-trigger-edit-profile");
    if (btnEdit) {
      btnEdit.addEventListener("click", openProfileEditModal);
    }
  }

  const btnTabProgress = document.getElementById("btn-tab-progress");
  const btnTabAchievements = document.getElementById("btn-tab-achievements");
  if (btnTabProgress && btnTabAchievements) {
    btnTabProgress.classList.toggle("active", currentProfileTab === "progress");
    btnTabAchievements.classList.toggle("active", currentProfileTab === "achievements");
  }

  // Aba 1: Desafios em Andamento
  if (tabProgress) {
    tabProgress.style.display = currentProfileTab === "progress" ? "block" : "none";
    
    if (inProgressList.length === 0) {
      tabProgress.innerHTML = `
        <div class="empty-state-box">
          <h3>Nenhum desafio em andamento ainda</h3>
          <p>Você ainda não iniciou nenhum desafio prático. Escolha seu primeiro desafio no catálogo e comece a praticar!</p>
          <button class="btn-primary" onclick="switchView('catalog')">Ir para o Catálogo de Desafios &rarr;</button>
        </div>
      `;
    } else {
      let cardsHtml = "";
      inProgressList.forEach(([chId, chData]) => {
        const fullChallenge = INITIAL_CHALLENGES.find(c => c.id === chId);
        if (fullChallenge) {
          cardsHtml += createChallengeCardHtml(fullChallenge, chData, true);
        }
      });
      tabProgress.innerHTML = `<div class="cards-grid">${cardsHtml}</div>`;
    }
  }

  // Aba 2: Conquistas
  if (tabAchievements) {
    tabAchievements.style.display = currentProfileTab === "achievements" ? "block" : "none";
    
    const userAchs = userData.achievements || [];
    let achsHtml = "";

    ACHIEVEMENTS_DEFINITIONS.forEach(ach => {
      const isUnlocked = userAchs.includes(ach.id);
      achsHtml += `
        <div class="achievement-row-card ${isUnlocked ? 'unlocked' : 'locked'}">
          <div class="achievement-icon-circle">
            ${isUnlocked ? Icons.trophy() : Icons.lock()}
          </div>
          <div class="achievement-details">
            <h4>${escapeHtml(ach.title)}</h4>
            <p>${escapeHtml(ach.description)}</p>
          </div>
          <span class="achievement-status-tag ${isUnlocked ? 'unlocked' : 'locked'}">
            ${isUnlocked ? '✓ Desbloqueada' : 'Bloqueada'}
          </span>
        </div>
      `;
    });

    tabAchievements.innerHTML = `<div class="achievements-list">${achsHtml}</div>`;
  }
}

function renderAllViews() {
  renderTopUserBar();
  renderHomeView();
  renderCatalogView();
  renderProfileView();
}

function switchView(viewName) {
  const views = {
    home: document.getElementById("view-home"),
    catalog: document.getElementById("view-catalog"),
    profile: document.getElementById("view-profile")
  };

  const navItems = {
    home: document.getElementById("nav-home"),
    catalog: document.getElementById("nav-catalog"),
    profile: document.getElementById("nav-profile")
  };

  Object.entries(views).forEach(([name, el]) => {
    if (el) el.classList.toggle("active", name === viewName);
  });

  Object.entries(navItems).forEach(([name, btn]) => {
    if (btn) btn.classList.toggle("active", name === viewName);
  });

  window.scrollTo({ top: 0, behavior: "smooth" });

  if (viewName === "home") renderHomeView();
  if (viewName === "catalog") renderCatalogView();
  if (viewName === "profile") renderProfileView();
}

// ==========================================================================
// 6. MODAL DE VISUALIZAÇÃO E ENTREGA DO DESAFIO
// ==========================================================================

let activeModalChallengeId = null;

function openChallengeModal(challengeId) {
  const challenge = INITIAL_CHALLENGES.find(c => c.id === challengeId);
  if (!challenge) return;

  activeModalChallengeId = challengeId;
  const modal = document.getElementById("modal-challenge");
  const user = state.getCurrentUser();
  const userData = state.getUserData(user?.id);
  const chData = userData.challenges[challengeId] || {
    status: "not_started",
    progress: 0,
    bookmarked: false,
    githubUrl: "",
    githubDeliveredAt: null,
    checkedSteps: []
  };

  document.getElementById("modal-ch-title").textContent = challenge.title;
  document.getElementById("modal-ch-subtitle").textContent = challenge.subtitle;
  document.getElementById("modal-ch-level").textContent = `Nível: ${challenge.level}`;
  document.getElementById("modal-ch-description").textContent = challenge.description;

  const tagsWrap = document.getElementById("modal-ch-tags");
  tagsWrap.innerHTML = challenge.tags.map(t => `<span class="tag-badge tech">${escapeHtml(t)}</span>`).join("");

  updateModalStatusUi(chData.status, chData.progress);
  renderModalChecklist(challenge, chData);

  const stepsList = document.getElementById("modal-ch-steps");
  stepsList.innerHTML = challenge.steps.map(s => `<li>${escapeHtml(s)}</li>`).join("");

  renderGithubSection(chData);

  const btnModalBookmark = document.getElementById("btn-modal-bookmark");
  if (btnModalBookmark) {
    btnModalBookmark.innerHTML = `${Icons.bookmark("", chData.bookmarked)} ${chData.bookmarked ? 'Salvo nos favoritos' : 'Favoritar desafio'}`;
    btnModalBookmark.onclick = () => {
      const newState = state.toggleBookmark(challengeId);
      btnModalBookmark.innerHTML = `${Icons.bookmark("", newState)} ${newState ? 'Salvo nos favoritos' : 'Favoritar desafio'}`;
      renderAllViews();
    };
  }

  modal.classList.add("active");
  document.body.style.overflow = "hidden";
}

function closeChallengeModal() {
  const modal = document.getElementById("modal-challenge");
  modal.classList.remove("active");
  document.body.style.overflow = "";
  activeModalChallengeId = null;
  renderAllViews();
}

function updateModalStatusUi(status, progress) {
  const statusBadge = document.getElementById("modal-ch-status-badge");
  const progressBar = document.getElementById("modal-ch-progress-bar");
  const progressLabel = document.getElementById("modal-ch-progress-label");

  let statusText = "Não iniciado";
  let statusClass = "neutral";

  if (status === "in_progress") {
    statusText = "Em andamento";
    statusClass = "info";
  } else if (status === "completed") {
    statusText = "Concluído";
    statusClass = "success";
  }

  statusBadge.className = `status-badge ${statusClass}`;
  statusBadge.textContent = statusText;

  progressBar.style.width = `${progress}%`;
  progressLabel.textContent = `${progress}%`;
}

function renderModalChecklist(challenge, chData) {
  const checklistWrap = document.getElementById("modal-ch-requirements");
  const checked = chData.checkedSteps || [];

  checklistWrap.innerHTML = challenge.requirements.map((req, idx) => {
    const isChecked = checked.includes(idx);
    return `
      <label class="req-item ${isChecked ? 'completed' : ''}">
        <input type="checkbox" data-req-index="${idx}" ${isChecked ? 'checked' : ''}>
        <span>${escapeHtml(req)}</span>
      </label>
    `;
  }).join("");

  checklistWrap.querySelectorAll("input[type='checkbox']").forEach(cb => {
    cb.addEventListener("change", (e) => {
      const user = state.getCurrentUser();
      if (!user) {
        showToast("Aviso", "Crie uma conta ou faça login para salvar seu progresso nos desafios!", "error");
        e.target.checked = !e.target.checked;
        return;
      }

      const idx = parseInt(e.target.dataset.reqIndex);
      let newChecked = [...(chData.checkedSteps || [])];

      if (e.target.checked) {
        if (!newChecked.includes(idx)) newChecked.push(idx);
      } else {
        newChecked = newChecked.filter(i => i !== idx);
      }

      chData.checkedSteps = newChecked;
      const total = challenge.requirements.length;
      const progressPercent = Math.round((newChecked.length / total) * 100);
      chData.progress = progressPercent;

      if (progressPercent === 100) {
        chData.status = "completed";
        state.unlockAchievement("first_completion");
        
        const uData = state.getUserData(user.id);
        const compCount = Object.values(uData.challenges).filter(c => c.status === "completed").length;
        if (compCount >= 3) {
          state.unlockAchievement("three_completed");
        }

        if (challenge.level === "Avançado") {
          state.unlockAchievement("advanced_master");
        }
      } else if (progressPercent > 0) {
        chData.status = "in_progress";
        state.unlockAchievement("first_step");
        if (progressPercent >= 50) {
          state.unlockAchievement("in_progress_50");
        }
      } else {
        chData.status = "not_started";
      }

      state.updateChallengeData(activeModalChallengeId, chData);
      updateModalStatusUi(chData.status, chData.progress);
      renderModalChecklist(challenge, chData);
    });
  });
}

function renderGithubSection(chData) {
  const container = document.getElementById("modal-ch-github-container");
  if (!container) return;

  const hasDelivery = !!chData.githubUrl;

  if (hasDelivery) {
    container.innerHTML = `
      <div class="delivery-status-box">
        <div class="delivery-link-info">
          <span class="status-badge success">${Icons.check()} Repositório entregue</span>
          <a href="${escapeHtml(chData.githubUrl)}" target="_blank" rel="noopener noreferrer">
            ${Icons.github()} ${escapeHtml(chData.githubUrl)} ${Icons.externalLink()}
          </a>
          <span style="font-size: 11px; color: var(--color-primary-500); font-weight: 700;">Entregue em: ${new Date(chData.githubDeliveredAt || Date.now()).toLocaleDateString("pt-BR")}</span>
        </div>
        <div class="delivery-actions">
          <button class="btn-outline btn-sm" id="btn-edit-github">Alterar link</button>
          <button class="btn-outline btn-sm" id="btn-remove-github" style="color: var(--color-error);">Remover</button>
        </div>
      </div>
    `;

    document.getElementById("btn-edit-github")?.addEventListener("click", () => {
      renderGithubInputForm(chData.githubUrl);
    });

    document.getElementById("btn-remove-github")?.addEventListener("click", () => {
      const user = state.getCurrentUser();
      if (!user) return;
      chData.githubUrl = "";
      chData.githubDeliveredAt = null;
      state.updateChallengeData(activeModalChallengeId, chData);
      renderGithubSection(chData);
      showToast("Entrega removida", "O link do repositório foi desvinculado.", "info");
    });
  } else {
    renderGithubInputForm("");
  }
}

function renderGithubInputForm(currentVal = "") {
  const container = document.getElementById("modal-ch-github-container");
  if (!container) return;

  container.innerHTML = `
    <div style="display: flex; flex-direction: column; gap: 8px;">
      <p style="font-size: var(--text-small); color: var(--color-primary); font-weight: 700;">Insira a URL do seu repositório no GitHub contendo a solução do desafio:</p>
      <div style="display: flex; gap: 8px; flex-wrap: wrap;">
        <input type="url" id="input-github-repo" class="form-control" style="flex: 1; min-width: 240px;" placeholder="https://github.com/seu-usuario/desafio-commit" value="${escapeHtml(currentVal)}">
        <button class="btn-secondary" id="btn-save-github">${Icons.github()} Salvar repositório</button>
      </div>
      <div id="github-error-msg" class="field-error-msg" style="display: none;"></div>
    </div>
  `;

  document.getElementById("btn-save-github")?.addEventListener("click", () => {
    const input = document.getElementById("input-github-repo");
    const errorEl = document.getElementById("github-error-msg");
    const val = input.value.trim();

    const user = state.getCurrentUser();
    if (!user) {
      showToast("Aviso", "Você precisa estar conectado para registrar a entrega do repositório!", "error");
      openAuthModal("login");
      return;
    }

    const githubRegex = /^https?:\/\/(www\.)?github\.com\/[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+\/?$/;
    if (!githubRegex.test(val)) {
      input.classList.add("has-error");
      errorEl.style.display = "flex";
      errorEl.innerHTML = `${Icons.alert()} Opa! Insira um endereço válido do GitHub. Exemplo: https://github.com/usuario/meu-projeto`;
      return;
    }

    input.classList.remove("has-error");
    errorEl.style.display = "none";

    const updated = state.updateChallengeData(activeModalChallengeId, {
      githubUrl: val,
      githubDeliveredAt: new Date().toISOString()
    });

    state.unlockAchievement("first_commit");
    showToast("Operação concluída.", "Link do GitHub salvo com sucesso!", "success");
    renderGithubSection(updated);
  });
}

// ==========================================================================
// 7. MODAL DE EDIÇÃO DE PERFIL
// ==========================================================================

function openProfileEditModal() {
  const user = state.getCurrentUser();
  if (!user) {
    openAuthModal("login");
    return;
  }

  const modal = document.getElementById("modal-profile-edit");

  document.getElementById("edit-profile-name").value = user.name || "";
  document.getElementById("edit-profile-username").value = user.username || "";
  document.getElementById("edit-profile-tag").value = user.tag || "Iniciante";
  document.getElementById("edit-profile-email").value = user.email || "";
  document.getElementById("edit-profile-bio").value = user.bio || "";

  document.getElementById("profile-edit-error").style.display = "none";

  modal.classList.add("active");
  document.body.style.overflow = "hidden";
}

function closeProfileEditModal() {
  const modal = document.getElementById("modal-profile-edit");
  modal.classList.remove("active");
  document.body.style.overflow = "";
}

// ==========================================================================
// 8. MODAL DE AUTENTICAÇÃO E CADASTRO LOCAL
// ==========================================================================

function openAuthModal(tab = "login") {
  const modal = document.getElementById("modal-auth");

  const btnTabLogin = document.getElementById("btn-auth-tab-login");
  const btnTabRegister = document.getElementById("btn-auth-tab-register");
  const formLogin = document.getElementById("form-auth-login");
  const formRegister = document.getElementById("form-auth-register");
  const authError = document.getElementById("auth-error-msg");

  if (authError) authError.style.display = "none";

  if (tab === "login") {
    btnTabLogin?.classList.add("active");
    btnTabRegister?.classList.remove("active");
    if (formLogin) formLogin.style.display = "block";
    if (formRegister) formRegister.style.display = "none";
  } else {
    btnTabLogin?.classList.remove("active");
    btnTabRegister?.classList.add("active");
    if (formLogin) formLogin.style.display = "none";
    if (formRegister) formRegister.style.display = "block";
  }

  modal.classList.add("active");
  document.body.style.overflow = "hidden";
}

function closeAuthModal() {
  const modal = document.getElementById("modal-auth");
  modal.classList.remove("active");
  document.body.style.overflow = "";
}

// ==========================================================================
// 9. INICIALIZAÇÃO DE EVENT LISTENERS GLOBAIS
// ==========================================================================

document.addEventListener("DOMContentLoaded", () => {
  // 0. Alternância de Modo Claro e Escuro (PDF IHC v3.0 Pág. 4)
  document.getElementById("btn-theme-toggle")?.addEventListener("click", toggleTheme);
  applyTheme(getCurrentTheme(), false);

  document.getElementById("nav-home")?.addEventListener("click", () => switchView("home"));
  document.getElementById("nav-catalog")?.addEventListener("click", () => switchView("catalog"));
  document.getElementById("nav-profile")?.addEventListener("click", () => switchView("profile"));
  document.getElementById("logo-btn")?.addEventListener("click", () => switchView("home"));
  document.getElementById("link-view-catalog")?.addEventListener("click", () => switchView("catalog"));

  document.getElementById("btn-tab-progress")?.addEventListener("click", () => {
    currentProfileTab = "progress";
    renderProfileView();
  });
  document.getElementById("btn-tab-achievements")?.addEventListener("click", () => {
    currentProfileTab = "achievements";
    renderProfileView();
  });

  const searchInput = document.getElementById("catalog-search-input");
  if (searchInput) {
    searchInput.addEventListener("input", (e) => {
      catalogFilter.search = e.target.value;
      renderCatalogView();
    });
  }

  document.querySelectorAll(".filter-pill").forEach(pill => {
    pill.addEventListener("click", () => {
      const group = pill.dataset.filterGroup;
      const val = pill.dataset.value;
      if (group === "level") catalogFilter.level = val;
      if (group === "status") catalogFilter.status = val;
      updateFilterPillsUi();
      renderCatalogView();
    });
  });

  document.getElementById("btn-clear-all-filters")?.addEventListener("click", () => {
    catalogFilter = { search: "", level: "Todos", tag: "Todos", status: "Todos" };
    if (searchInput) searchInput.value = "";
    updateFilterPillsUi();
    renderCatalogView();
  });

  document.addEventListener("click", (e) => {
    const openBtn = e.target.closest("[data-action='open-modal']");
    if (openBtn) {
      const chId = openBtn.dataset.id;
      openChallengeModal(chId);
      return;
    }

    const bookmarkBtn = e.target.closest("[data-action='bookmark']");
    if (bookmarkBtn) {
      e.stopPropagation();
      const chId = bookmarkBtn.dataset.id;
      const user = state.getCurrentUser();
      if (!user) {
        showToast("Aviso", "Faça login para salvar desafios nos favoritos!", "info");
        openAuthModal("login");
        return;
      }
      const isBookmarked = state.toggleBookmark(chId);
      bookmarkBtn.classList.toggle("bookmarked", isBookmarked);
      bookmarkBtn.innerHTML = Icons.bookmark("", isBookmarked);
      renderAllViews();
      return;
    }
  });

  document.querySelectorAll("[data-close-modal]").forEach(btn => {
    btn.addEventListener("click", () => {
      closeChallengeModal();
      closeProfileEditModal();
      closeAuthModal();
    });
  });

  document.querySelectorAll(".modal-overlay").forEach(overlay => {
    overlay.addEventListener("click", (e) => {
      if (e.target === overlay) {
        closeChallengeModal();
        closeProfileEditModal();
        closeAuthModal();
      }
    });
  });

  const formProfileEdit = document.getElementById("form-profile-edit");
  if (formProfileEdit) {
    formProfileEdit.addEventListener("submit", (e) => {
      e.preventDefault();
      const name = document.getElementById("edit-profile-name").value;
      const username = document.getElementById("edit-profile-username").value;
      const tag = document.getElementById("edit-profile-tag").value;
      const email = document.getElementById("edit-profile-email").value;
      const bio = document.getElementById("edit-profile-bio").value;
      const errorEl = document.getElementById("profile-edit-error");

      const result = state.updateProfile(name, username, tag, email, bio);
      if (result.success) {
        closeProfileEditModal();
        renderAllViews();
      } else {
        errorEl.style.display = "flex";
        errorEl.innerHTML = `${Icons.alert()} ${result.message}`;
      }
    });
  }

  document.getElementById("btn-auth-tab-login")?.addEventListener("click", () => openAuthModal("login"));
  document.getElementById("btn-auth-tab-register")?.addEventListener("click", () => openAuthModal("register"));

  document.getElementById("form-auth-login")?.addEventListener("submit", (e) => {
    e.preventDefault();
    const idInput = document.getElementById("login-username").value;
    const passInput = document.getElementById("login-password").value;
    const errorEl = document.getElementById("auth-error-msg");

    const res = state.login(idInput, passInput);
    if (res.success) {
      closeAuthModal();
      renderAllViews();
      showToast("Operação concluída.", `Bem-vindo de volta, ${res.user.name}!`, "success");
    } else {
      errorEl.style.display = "flex";
      errorEl.innerHTML = `${Icons.alert()} ${res.message}`;
    }
  });

  document.getElementById("form-auth-register")?.addEventListener("submit", (e) => {
    e.preventDefault();
    const name = document.getElementById("reg-name").value;
    const username = document.getElementById("reg-username").value;
    const email = document.getElementById("reg-email").value;
    const pass = document.getElementById("reg-password").value;
    const tag = document.getElementById("reg-tag").value;
    const bio = document.getElementById("reg-bio").value;
    const errorEl = document.getElementById("auth-error-msg");

    const res = state.register(name, username, email, pass, tag, bio);
    if (res.success) {
      closeAuthModal();
      renderAllViews();
    } else {
      errorEl.style.display = "flex";
      errorEl.innerHTML = `${Icons.alert()} ${res.message}`;
    }
  });

  document.getElementById("btn-quick-pedro")?.addEventListener("click", () => {
    document.getElementById("login-username").value = "pedro.dev";
    document.getElementById("login-password").value = "123";
  });

  document.getElementById("btn-quick-ana")?.addEventListener("click", () => {
    document.getElementById("login-username").value = "ana.dev";
    document.getElementById("login-password").value = "123";
  });

  document.getElementById("btn-modal-start-challenge")?.addEventListener("click", () => {
    const user = state.getCurrentUser();
    if (!user) {
      showToast("Aviso", "Faça login ou crie uma conta para iniciar o desafio!", "info");
      openAuthModal("login");
      return;
    }
    const updated = state.updateChallengeData(activeModalChallengeId, {
      status: "in_progress",
      progress: 25,
      checkedSteps: [0]
    });
    state.unlockAchievement("first_step");
    updateModalStatusUi(updated.status, updated.progress);
    const ch = INITIAL_CHALLENGES.find(c => c.id === activeModalChallengeId);
    if (ch) renderModalChecklist(ch, updated);
    renderAllViews();
    showToast("Desafio Iniciado!", "Bom trabalho! Continue seguindo os requisitos passo a passo.", "success");
  });

  document.getElementById("btn-modal-complete-challenge")?.addEventListener("click", () => {
    const user = state.getCurrentUser();
    if (!user) {
      showToast("Aviso", "Faça login para concluir o desafio!", "info");
      openAuthModal("login");
      return;
    }
    const ch = INITIAL_CHALLENGES.find(c => c.id === activeModalChallengeId);
    const allIndexes = ch.requirements.map((_, i) => i);
    const updated = state.updateChallengeData(activeModalChallengeId, {
      status: "completed",
      progress: 100,
      checkedSteps: allIndexes
    });
    state.unlockAchievement("first_completion");
    if (ch.level === "Avançado") state.unlockAchievement("advanced_master");

    updateModalStatusUi(updated.status, updated.progress);
    renderModalChecklist(ch, updated);
    renderAllViews();
    showToast("Parabéns!", "Desafio concluído com 100% de aproveitamento!", "achievement");
  });

  renderAllViews();
});
